package com.example.tugas1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void ButtonAlamat(View x){
        Uri mapUrl = Uri.parse("https://goo.gl/maps/8WMcv658xNo7TGU5A");
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, mapUrl);
        mapIntent.setPackage("com.google.android.apps.maps");
        startActivity(mapIntent);

    }

    public void ButtonTelepon(View x){
        Uri noTelp = Uri.parse("tel:082266368900");
        Intent teleponIntent = new Intent(Intent.ACTION_DIAL,noTelp);
        startActivity(teleponIntent);

    }

    public void ButtonEmail(View x){
        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setType("text/html");
        emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[] {"isiEmail@gmail.com","disini@gmail.com"});
        startActivity(emailIntent);
    }
}